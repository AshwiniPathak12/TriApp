import React, { Component } from "react";
import { ExcelRenderer, OutTable } from "react-excel-renderer";
//import { Dropzone } from "react-dropzone";
import { useDropzone } from "../node_modules/react-dropzone/dist/index.js";

class ExcelUploader extends Component {
  state = {
    file: null,
    data: [],
  };

  handleFileChange = (e) => {
    this.setState({
      file: e.target.files[0],
    });
  };

  handleExcelData = (data) => {
    this.setState({
      data: data,
    });
  };

  render() {
    const { file, data } = this.state;

    if (!file) {
      return (
        <div>
          <useDropzone onDrop={this.handleFileChange}>
            <p>Drag and drop your Excel file here</p>
          </useDropzone>
        </div>
      );
    }

    return (
      <div>
        <ExcelRenderer
          file={file}
          sheetName="Sheet1"
          showHeader={true}
          showFooter={false}
          tableClassName="my-table"
          onChange={this.handleExcelData}
        >
          <OutTable />
        </ExcelRenderer>
        {data && (
          <table className="my-table">
            {data.map((row) => (
              <tr key={row[0]}>
                {row.map((cell) => (
                  <td key={cell}>{cell}</td>
                ))}
              </tr>
            ))}
          </table>
        )}
      </div>
    );
  }
}

export default ExcelUploader;
