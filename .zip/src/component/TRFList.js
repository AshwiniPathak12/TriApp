import React from "react";
import Dates from "./Dates";
import "./trfList.css"
//import Card from "../UI/Card";

const TRFList = (props) => {
  const trf = props.trf;
  console.log(trf);

  return (
    <div className="trf">
      {/* <Card> */}
      <div>
        <table className="tb">
          <thead className="th">
            <tr>
              <th>Id</th>
              <th>Training Title</th>
              <th>Initiated from</th>
              <th>Training Type</th>
              <th>Project Name</th>
              <th>Resource Type</th>
              <th>Duration(In Days)</th>
              <th>No of participants</th>
              <th>Skills to be imparted</th>
              <th>Training Start Date(dd-mm-yyyy)</th>
              <th>Training End Date(dd-mm-yyyy)</th>
              <th>Purpose of training</th>
            </tr>
          </thead>

          <tbody className="td">
            {trf.map((user, key) => {
              return (
                <tr key={key}>
                  <td>{key + 1}</td>
                  <td>{user.trainingTitle} </td>
                  <td> {user.intiatedFrom} </td>
                  <td>{user.trainingType} </td>
                  <td>{user.projectName} </td>
                  <td>{user.resourceType}</td>
                  <td>{user.duration} </td>
                  <td>{user.count} </td>
                  <td>{user.skillsImparted} </td>
                  <td>
                    <Dates date={user.startDate} />
                  </td>
                  <td>
                    <Dates date={user.endDate} />
                  </td>
                  <td>{user.purposeOfTraining} </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        </div>
      {/* </Card> */}
    </div>
  );
};

export default TRFList;
