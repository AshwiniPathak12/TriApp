import React, { useState } from "react";
import "./TrainingIniSec.css";
import Button from "../UI/Button";
import Card from "../UI/Card";
import ErrorModal from "../Error/ErrorModal";

const TrainingInitiatiorSection = (props) => {
  const [selectedFile, setSelectedFile] = useState(null);
  //const [excelFile, setExcelFile] = useState(null);

   const handleFileChange = (event) => {
     setSelectedFile(event.target.files[0]);
   };

  const handleUpload = ({ onFileSelect }) => {
    if (selectedFile) {
      // Perform the file upload logic here
      console.log("Uploading file:", selectedFile);
    } else {
      console.log("No file selected");
    }
  };

  // const handleFileUpload = (event) => {
  //   const file = event.target.files[0];
  //   setExcelFile(file);
  //   };

  const [userInput, setUserInput] = useState({
    enteredTrainingTitle: "",
    enteredIntiatedFrom: "",
    enteredTrainingType: "",
    enteredProjectName: "",
    eresourceType: "",
    enteredDuration: 0,
    enteredcount: 0,
    enterskillsImparted: "",
    enteredPurposeOfTraining: "",
    enterstartDate: "",
    enteredEndDate: "",
  });

  const [error, setError] = useState();

  const trainingChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredTrainingTitle: event.target.value };
    });
  };

  const InitiatedChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredIntiatedFrom: event.target.value };
    });
  };

  const trainingTypeChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredTrainingType: event.target.value };
    });
  };

  const projectNameChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredProjectName: event.target.value };
    });
  };

  const resourceTypeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, eresourceType: event.target.value };
    });
  };
  //resourceType
  const durationChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredDuration: event.target.value };
    });
  };

  const countHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredcount: event.target.value };
    });
  };

  const enteredPurposeOfTrainingChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredPurposeOfTraining: event.target.value };
    });
  };
  //skillsImparted
  const enterskillsImpartedHandle = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enterskillsImparted: event.target.value };
    });
  };

  const enterstartDateHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enterstartDate: event.target.value };
    });
  };
  const enteredEndDateChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredEndDate: event.target.value };
    });
  };

  const trfFormSumbitHandler = (event) => {
    event.preventDefault();

    if (
      userInput.enteredTrainingTitle.trim().length === 0 ||
      userInput.enteredIntiatedFrom.trim().length === 0 ||
      userInput.enteredTrainingType.trim().length === 0 ||
      userInput.enteredProjectName.trim().length === 0 ||
      userInput.eresourceType.trim().length === 0 ||
      userInput.enterskillsImparted.trim().length === 0 ||
      userInput.enteredPurposeOfTraining.trim().length === 0
    ) {
      setError({
        title: "Invalid input",
        message: "please enter valid input",
      });
      return;
    }

    if (+userInput.enteredDuration < 1 || +userInput.enteredcount < 1) {
      setError({
        title: "Invalid Input",

        message: "Please Enter a Valid input greater then 0",
      });

      return;
    }

    const newTrf = {
      trainingTitle: userInput.enteredTrainingTitle,
      intiatedFrom: userInput.enteredIntiatedFrom,
      trainingType: userInput.enteredTrainingType,
      projectName: userInput.enteredProjectName,

      resourceType: userInput.eresourceType,
      duration: userInput.enteredDuration,
      count: userInput.enteredcount,
      skillsImparted: userInput.enterskillsImparted,

      purposeOfTraining: userInput.enteredPurposeOfTraining,
      startDate: new Date(userInput.enterstartDate),
      endDate: new Date(userInput.enteredEndDate),
    };

    props.onAddTrf(newTrf);
    setUserInput({
      enteredTrainingTitle: "",
      enteredIntiatedFrom: "",
      enteredTrainingType: "",
      enteredProjectName: "",
      eresourceType: "",
      enteredDuration: 0,
      enteredcount: 0,
      enterskillsImparted: "",

      enteredPurposeOfTraining: "",
      enterstartDate: "",
      enteredEndDate: "",
    });
  };

  const errorHadler = () => {
    setError(null);
  };

  return (
    <div>
      <div className="main">
        {error && (
          <ErrorModal
            onConfirm={errorHadler}
            title={error.title}
            message={error.message}
          />
        )}
        <Card>
          {/* <div> */}
          <h2>TraningRequestIntiator Section</h2>

          <br />
          <form onSubmit={trfFormSumbitHandler}>
            <div className="new__controls">
              <div className="new__control">
                <label htmlFor="traningTitle">Training Title :</label>
                <input
                  type="text"
                  name="trainingTitle"
                  id="TrainingTitle"
                  onChange={trainingChangeHandler}
                  value={userInput.enteredTrainingTitle}
                />
              </div>

              <div className="new__control">
                <label>Initiated From :</label>

                <input
                  type="text"
                  name="initiatedFrom"
                  id="intiatedFrom"
                  onChange={InitiatedChangeHandler}
                  value={userInput.enteredIntiatedFrom}
                />
              </div>
              <div className="new__control">
                <label>Training Type :</label>

                <select
                  // type="text"
                  name="trainingType"
                  id="trainingType"
                  onChange={trainingTypeChangeHandler}
                  value={userInput.enteredTrainingType}
                >
                  <option value=""> Select Option</option>
                  <option value="FRW(Future Ready Workforce)">
                    FRW(Future Ready Workforce)
                  </option>
                  <option value="DRWF(Digital Ready Workforce)">
                    DRWF(Digital Ready Workforce)
                  </option>
                  <option value="On Demand">On Demand</option>

                  <option value="Project Specific"> Project Specific</option>
                </select>
              </div>
              <div className="new__control">
                <label>Project Name :</label>

                <input
                  type="text"
                  name="projectName"
                  id="ProjectName"
                  onChange={projectNameChangeHandler}
                  value={userInput.enteredProjectName}
                />
              </div>

              <div className="new__control">
                <label>Resource Type :</label>

                <select
                  type="text"
                  name="resourceType"
                  id="resourceType"
                  onChange={resourceTypeHandler}
                  value={userInput.eresourceType}
                >
                  <option value=""> Select Option</option>
                  <option value="DRWF(Digital Ready Workforce)">
                    DRWF(Digital Ready Workforce)
                  </option>
                  <option value="Fresher">Fresher</option>

                  <option value="Lateral"> Lateral</option>
                  <option value="CDAC"> CDAC</option>
                  <option value="Interns"> Interns</option>
                  <option value="On Bench"> On Bench</option>
                </select>
              </div>

              <div className="new__control">
                <label>Duration :</label>
                <input
                  type="number"
                  name="duration"
                  id="Duration"
                  onChange={durationChangeHandler}
                  value={userInput.enteredDuration}
                  required
                />
              </div>

              <div className="new__control">
                <label>No of Participants : </label>
                <input
                  type="number"
                  name="count"
                  id="count"
                  onChange={countHandler}
                  value={userInput.enteredcount}
                  required
                />
              </div>

              <div className="new__control">
                <label>Skill To Be Imparted : </label>
                <input
                  type="text"
                  name="skillsImparted"
                  id="skillsImparted"
                  onChange={enterskillsImpartedHandle}
                  value={userInput.enterskillsImparted}
                />
              </div>

              <div className="new__control">
                <label>Purpose of Training :</label>

                <input
                  type="text"
                  name="trainingTitle"
                  id="PurposeOfTraining"
                  onChange={enteredPurposeOfTrainingChangeHandler}
                  value={userInput.enteredPurposeOfTraining}
                />
              </div>

              <div className="new__control">
                <label>Training Start Date : &nbsp; </label>
                <input
                  type="date"
                  name="startDate"
                  id="startDate"
                  onChange={enterstartDateHandler}
                  value={userInput.enterstartDate}
                  required
                />
              </div>
              <div className="new__control">
                <label>TrainingEnd Date : &nbsp;</label>

                <input
                  type="date"
                  name="endDate"
                  id="EndDate"
                  onChange={enteredEndDateChangeHandler}
                  value={userInput.enteredEndDate}
                  required
                />
              </div>
              <div>
                <Button type="submit">Next</Button> &nbsp;
              </div>
            </div>
          </form>

          <div>
            <input
              type="file"
              accept=".xlsx, .xls"
               onChange={handleFileChange}
            />
            <Button onClick={handleUpload}>Upload</Button>
          </div>

          <br />
        </Card>
        {/* </div> */}
      </div>
    </div>
  );
};

export default TrainingInitiatiorSection;
