// import React from 'react'

// export default function Header() {
//   return (
//     <div style={{backgroundColor:"#A4D5D5",height:"30px"}}>
    
//     <b>TRAINING REQUEST FORM</b>
    
//     </div>
//   )
// }
