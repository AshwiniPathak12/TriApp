import React from 'react';

 import classes from './Navigation.module.css';
//import Button from '../../UI/Button';

const Navigation = (props) => {
  return (
    <nav className={classes.nav}>
       {/*  <ul>
       {props.isLoggedIn && (
          <li>
            <a href="/">Users</a>
          </li>
        )}
        {props.isLoggedIn && (
          <li>
            <a href="/">Admin</a>
          </li>
        )} */}
        {props.isLoggedIn && (
          <div>
          
            <button onClick={props.onLogout}>Logout</button>
          </div>
        )}
      
    </nav>
  );
};

export default Navigation;
