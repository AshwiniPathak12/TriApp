import React , {useState} from 'react';

import classes from './Home.module.css';
//import Card from '../../UI/Card';
import TrainingInitiatiorSection from '../TrainingInitiatiorSection';
import TRFList from '../TRFList';



const initailList = [
    {
      id: 1,
      trainingTitle: "Java Trainning for Testing Pool",
      intiatedFrom: "Vikas Pandharpurkar",
      trainingType: "FRW(Future Ready Workforce)",
      projectName: "jd",
      resourceType: "on Bench",
      duration: 23,
      count: 30,
      skillsImparted: "Java",
      startDate: new Date(2021, 1, 6),
      endDate: new Date(2022, 1, 6),
      purposeOfTraining: "Capablity Building",
    },
  ];

const Home = (props) => {

    const [trf, setTrfData] = useState(initailList);

    const addTrfHandler = (trfdata) => {
        //console.log(trfdata);
        setTrfData((prevTrfdata) => {
          return [trfdata, ...prevTrfdata];
        });
      };

    return (
        // Card
      <div className={classes.home}>
      
      <TrainingInitiatiorSection onAddTrf={addTrfHandler} />
      <TRFList trf={trf} />
        {/* <h1>Welcome back!</h1> */}
      </div>
    );
  };
  
  export default Home;
  